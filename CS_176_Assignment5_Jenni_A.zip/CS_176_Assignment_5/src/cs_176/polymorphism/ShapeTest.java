package cs_176.polymorphism;

import java.util.Arrays;





public class ShapeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Circle[] circle = new Circle[3]; // currently contains only nulls

		Circle circle1 = new Circle(0, 1, 2);
		
		Circle circle2 = new Circle(3,2,4);
		
		Circle circle3 = new Circle(4,5,1);
	    
		
		Arrays.sort(circle);
	       
	       System.out.println(circle);
	       
	       
	       Rectangle [] rect = new Rectangle[3]; 

		
		Rectangle rect1 = new Rectangle(5,10,20,3);
		Rectangle rect2 = new Rectangle(4,8,5,2);
		Rectangle rect3 = new Rectangle(6,9,8,10);
		
			
		
			Arrays.sort(rect);
	       
	       System.out.println(rect);
	       
	       
	       circle1.moveLeft(3);
	       circle1.moveUp(2);
	       
	       System.out.println(circle1);
	       
	       rect2.moveLeft(2);
	       rect2.moveUp(3);
	       
	       System.out.println(rect2);
	       
	       
	       Cuboid cuboid1 = new Cuboid(5, 10, 2, 20, 3, 2);
	       Cuboid cuboid2 = new Cuboid(4,8,6,5,2,10);
	       
	       cuboid1.getVolume();
	       cuboid2.getVolume();
	       
	       cuboid1.compareTo(cuboid2);
		
		System.out.println(" -1 = Cuboid 1 has smaller vol. \n "
				+ "1 = Cuboid 1 has bigger vol. \n ");
		
		
		
		
	}

}
