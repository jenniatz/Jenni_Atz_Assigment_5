package cs_176.polymorphism;

public interface Moveable {
	//TODO: add method
	
	public void moveUp(int y);
	
	public void moveDown(int y);

	public void moveLeft(int x);

	public void moveRight(int x);

}