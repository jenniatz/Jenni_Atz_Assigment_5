package cs_176.polymorphism;




public class Circle extends Shape implements Comparable<Object>, Moveable {
	private int x;
	private int y;
	private int r; 

	//private ArrayList<Object> object = new ArrayList<Object>();

		public Circle(int x, int y, int r) {
			this.x = x;
			this.y = y;
			this.r = r;
		}
		
		public int getX() {
			return x;
		}

		public void setX(int x) {
			this.x = x;
		}

		public int getY() {
			return y;
		}

		public void setY(int y) {
			this.y = y;
		}

		public int getR() {
			return r;
		}

		public void setR(int r) {
			this.r = r;
		}

		public double getArea() {
			return Math.PI * Math.pow(r, 2); 
		}
		
		public String toString() {
			String s = this.getClass().toString();
			s = s + ": " + this.x + ", " + this.y + ", " + this.r + "; ";
			return s;
		}
		
		public boolean equals(Object obj) {
			if (obj instanceof Circle) {
				Circle other = (Circle) obj;
				if (this.x == other.x && this.y == other.y && this.r == other.r) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		
			
		
		
		public int compareTo(Object o) {
			// TODO Auto-generated method stub
			
			
		
		//	return getR() - ((Circle) o).getR();
			
			
			if(o instanceof Circle) {			
				Circle other = (Circle) o;
				
				if(this.getR() < other.getR()) {
					return -1;
			
				} else if(this.getR() > other.getR()) {					
					return 1;
				} else {
					return 0;
				}
		}
			return 0;
	}
			
		public Circle(int x, int y) {
			
			this.x = x;
			
			this.y = y;
			
			
		}

		
	

		@Override
		public void moveUp(int y) {
			// TODO Auto-generated method stub
			y--;
		}

		@Override
		public void moveDown(int y) {
			// TODO Auto-generated method stub
			y++;
		}

		@Override
		public void moveLeft(int x) {
			// TODO Auto-generated method stub
			x--;
		}

		@Override
		public void moveRight(int x) {
			// TODO Auto-generated method stub
			x++;
		}

		
	
			
	 
	     
			
		}
		

